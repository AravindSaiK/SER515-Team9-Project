import React, {useState} from 'react';
import { useDrop } from 'react-dnd'
import ItemTypes from './ItemTypes'
import Item from './Items'
import Items from './ItemsCustom'
import { DropTarget } from 'react-dnd'
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import { useHistory } from 'react-router-dom'



/**
 * @author Nikhila Saini, Krishna Gurram ,Venkata Sairam
 * Since Nov 3,2019
 */

const style = {
    backgroundColor: "white",
    width: "48%",
    height: "800px",
    float: "left",
    borderStyle: "ridge"
}
const ThirdSandBoxPanel = () => {
    const numbers = []
    let add = false;
    let exp = ""
    let sum = 0;
    let result = 6
    const history  = useHistory();
    const [items, addItems] = useState([]);
    const [{ canDrop, isOver,item,dropped }, drop] = useDrop({
        accept: ItemTypes.BOX,
       drop: (monitor,component) => ({ 
            item: component.getItem(),
            items: addItems(items.concat(item.num)),
            name:  'SandBoxPanel'}),
        
        collect: monitor => ({
            isOver: monitor.isOver(),
            canDrop: monitor.canDrop(),
            item: monitor.getItem(),
            dropped: monitor.didDrop(),
            //items:  handleDrop(item.num)
            }),
    })
    const isActive = canDrop && isOver
    let backgroundColor = 'white'
    

const display = (items) => {
    return (
        items.map((number) => (
                    <Items  num = {number} />
                ))
        )

}
const evaluate = (items) => {
    if(items.length == 1 && items[0] == result)
    {    alert("You can't have the same number as answer. Please try to add more numbers")
         return
    }
    var lastNum = ""
    items.map((number) =>{
                    
                    if(isNaN(number)){
                        if(number == "+" || number == "-")
                             exp = exp +"0"+number
                         else if(number == "*" || number == "/")
                            exp = exp +"1"+number
                         else if(number == "(")
                            return exp
                            }
                            else
                                exp = exp + number
                })
 try {
        sum = eval(exp)
        console.log(exp)
    }catch (e){
       
       
        sum = 0
        alert("Sorry!, You Failed the test. Going back to home")
           //redirect()
           return "error"

    }
    console.log(sum)

    if(result == sum)
        alert("Congratulations!. You've Passed the test. Going back to home")
    else
        alert("Sorry!, You Failed the test. Going back to home")
   // alert("hi")
   //redirect()
}

const redirect= () => {
    history.push("/Main")
}
    
    return (
        <div>
        <div  ref = {drop} style={{...style, backgroundColor}}>
                {isActive ? items.length >= 1 ? display(items):<Items num={item.num} />: items.length > 0 ? display(items):"Drop Your equation Here"  }
        </div>
         

        <div>
        <div  className="ResultPanel">
        <span className="task-header">Result Panel</span>
            <div style={{display:"none"}}>{
                numbers.map((number) => (
                    exp = exp + number
                ))


            }
            </div>
            <div>
            <br/>
            
                
            Write an Equation which evaluates to the below number<Items num={6} />
            <div> <br/><Button variant="contained" color="primary"  onClick={() => evaluate(items)}>Submit</Button></div>
            </div>
            
    </div>
</div>
        </div>
    )
}


export default (ThirdSandBoxPanel);