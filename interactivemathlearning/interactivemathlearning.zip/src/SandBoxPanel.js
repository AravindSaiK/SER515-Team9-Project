import React, {useState} from 'react';
import { useDrop } from 'react-dnd'
import ItemTypes from './ItemTypes'
import Item from './Items'
import Items from './ItemsCustom'
import { DropTarget } from 'react-dnd'



/**
 * @author Nikhila Saini, Krishna Gurram ,Venkata Sairam
 * Since Nov 3,2019
 */

const style = {
    backgroundColor: "lightgoldenrodyellow",
    width: "48%",
    height: "800px",
    float: "left",
    borderStyle: "ridge"
}
const SandBoxPanel = (num) => {
    const numbers = []
    let add = false;
    let exp = ""
    let sum = 0;
    const [items, addItems] = useState([]);
    const [{ canDrop, isOver,item,dropped }, drop] = useDrop({
        accept: ItemTypes.BOX,
        drop: (monitor,component) => ({ 
            item: component.getItem(),
            items: addItems(items.concat(item.num)),
            name:  'SandBoxPanel'}),
        
        collect: monitor => ({
            isOver: monitor.isOver(),
            canDrop: monitor.canDrop(),
            item: monitor.getItem(),
            dropped: monitor.didDrop(),
            //items:  handleDrop(item.num)
            }),
    })
    const isActive = canDrop && isOver
    let backgroundColor = 'white'


const display = (items) => {
    return (
        items.map((number) => (
                    <Items  num = {number} />
                ))
        )

}

const evaluate = (items) => {
    var lastNum = ""
    items.map((number) =>{
                    exp = exp + number
                    if(isNaN(number)){
                        if(number == "+" || number == "-")
                             exp = exp +"0"+number
                         else if(number == "*" || number == "/")
                            exp = exp +"1"+number

                         
                            }
                            console.log(exp)
                })
//console.log(exp)
 try {
        sum = eval(exp)
        //console.log()
    }catch (e){
        if(e instanceof SyntaxError )
    {   
        sum = 0
        return "error"
    }
    }
    //console.log(sum)
    return sum

}
 
//console.log(item)
    return (
        <div>
            <div ref={drop} style={{...style, backgroundColor}}>
                {isActive ? items.length >= 1 ? display(items):<Items num={item.num} />: items.length > 0 ? display(items):"Drop Here"  }
            </div>

            <div>
                <div  className="ResultPanel">
                    <span className="task-header" >Result Panel</span>

                    {items.length > 0 ? <Items num={evaluate(items)}/> : ""}
                </div>
            </div>
        </div>
)
}


export default SandBoxPanel;