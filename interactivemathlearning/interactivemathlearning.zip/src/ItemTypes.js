export default {
    BOX: 'box',
}
