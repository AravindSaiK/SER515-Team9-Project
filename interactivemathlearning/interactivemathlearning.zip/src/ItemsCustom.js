import React, {useState} from 'react';
import { useDrag } from 'react-dnd'
import ItemTypes from './ItemTypes'

/**
 * @author Nikhila Saini
 * Since Nov 3,2019
 */



const ItemsCustom = ({ num,numbers }) => {
    //const [nums,addNums] = useState([]);
    /*const [{ isDragging }, drag] = useDrag({
        item: { num, type: ItemTypes.BOX },
        end: (item, monitor) => {
            const dropResult = monitor.getDropResult()
            if (item && dropResult) {
               // alert(`You dropped ${item.num} into ${dropResult.name}!`)
            }
        },
        collect: monitor => ({
            isDragging: monitor.isDragging(),
        }),
    })
    const opacity = isDragging ? 0.4 : 1*/

    //console.log(numbers)


    const color = isNaN(num) ? "#f58231": "#4363d8" 
    const style = {
    border: '1px dashed gray',
    backgroundColor: color,
    padding: '0.5rem 1rem',
    marginRight: '1.5rem',
    marginBottom: '1.5rem',
    marginTop: '1rem',
    cursor: 'move',
    float: 'left',
    color: 'white'
}
    return (
        <div style={{ ...style }}>
            {num}
        </div>)
}



export default ItemsCustom;